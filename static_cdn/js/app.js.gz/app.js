
document.addEventListener('DOMContentLoaded', function () {
    var currentYear = new Date().getFullYear();
    document.getElementById('footerDate').innerHTML = currentYear;
  
});


